# ShopEase
Quick start (no MongoDB needed): run `start-windows.bat` or `./start-mac-linux.sh`, then open http://localhost:5173
API docs: http://localhost:8000/docs
Real MongoDB: set MONGO_URL=mongodb://localhost:27017 (data seeds automatically on first start).
Logins: user@shopease.com / user1234 | admin@shopease.com / admin1234
Chatbot hook: backend/app/routes/chat.py (POST /chat). Policies for RAG: backend/data/policies/*.json
