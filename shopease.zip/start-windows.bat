@echo off
start "ShopEase API" cmd /k "cd backend && pip install -r requirements.txt && set MONGO_URL=mock && uvicorn app.main:app --port 8000"
start "ShopEase Web" cmd /k "cd frontend && npm install && npm run dev"
echo Open http://localhost:5173
