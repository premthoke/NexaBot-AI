#!/bin/bash
# Uses in-memory DB by default. For real MongoDB: MONGO_URL=mongodb://localhost:27017 ./start-mac-linux.sh
export MONGO_URL=${MONGO_URL:-mock}
(cd backend && pip install -r requirements.txt && uvicorn app.main:app --port 8000) &
(cd frontend && npm install && npm run dev)
