import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import ChatWidget from "./components/ChatWidget";
import Home from "./pages/Home";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Login from "./pages/Login";
import Support from "./pages/Support";
import Checkout from "./pages/Checkout";
import Orders from "./pages/Orders";
import Profile from "./pages/Profile";
import Admin from "./pages/Admin";
export default function App() {
  return (
    <>
      <Navbar />
      <main className="max-w-7xl mx-auto p-4 min-h-[70vh]">
        <Routes>
          <Route path="/" element={<Home />} /><Route path="/products" element={<Products />} />
          <Route path="/product/:id" element={<ProductDetail />} /><Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} /><Route path="/orders" element={<Orders />} /><Route path="/profile" element={<Profile />} /><Route path="/admin" element={<Admin />} />
          <Route path="/login" element={<Login />} /><Route path="/support" element={<Support />} /><Route path="/support/:slug" element={<Support />} />
        </Routes>
      </main>
      <footer className="bg-stone-900 text-stone-300 text-sm p-8 mt-10 text-center">© ShopEase · Help: <a className="underline" href="/support">Support centre</a></footer>
      <ChatWidget />
    </>
  );
}
