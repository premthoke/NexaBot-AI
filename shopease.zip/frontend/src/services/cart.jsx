import { createContext, useContext, useEffect, useState } from "react";
const Ctx = createContext();
export const useCart = () => useContext(Ctx);
export function CartProvider({ children }) {
  const [items, setItems] = useState(() => JSON.parse(localStorage.getItem("cart") || "[]"));
  useEffect(() => localStorage.setItem("cart", JSON.stringify(items)), [items]);
  const add = (p, q = 1) => setItems((s) => s.some((i) => i.product_id === p.product_id)
    ? s.map((i) => i.product_id === p.product_id ? { ...i, quantity: i.quantity + q } : i)
    : [...s, { product_id: p.product_id, title: p.title, price: p.price, image: p.images[0], quantity: q }]);
  const setQty = (id, q) => setItems((s) => s.map((i) => i.product_id === id ? { ...i, quantity: Math.max(1, q) } : i));
  const remove = (id) => setItems((s) => s.filter((i) => i.product_id !== id));
  const clear = () => setItems([]);
  const total = items.reduce((a, i) => a + i.price * i.quantity, 0);
  return <Ctx.Provider value={{ clear, items, add, setQty, remove, total, count: items.reduce((a, i) => a + i.quantity, 0) }}>{children}</Ctx.Provider>;
}
