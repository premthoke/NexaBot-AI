import { Link } from "react-router-dom";
import { useCart } from "../services/cart";
export default function Cart() {
  const { items, setQty, remove, total } = useCart();
  if (!items.length) return <p>Your cart is empty. <Link to="/products" className="text-brand underline">Start shopping</Link></p>;
  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold mb-4">Your cart</h1>
      {items.map((i) => (
        <div key={i.product_id} className="flex items-center gap-4 bg-white border rounded p-3 mb-2">
          <img src={i.image} className="w-16 h-16 rounded" /><div className="flex-1"><div className="font-medium">{i.title}</div><div>₹{i.price.toLocaleString("en-IN")}</div></div>
          <input type="number" min="1" value={i.quantity} onChange={(e) => setQty(i.product_id, +e.target.value)} className="w-16 border rounded p-1" />
          <button onClick={() => remove(i.product_id)} className="text-red-600 text-sm">Remove</button>
        </div>))}
      <div className="text-right text-xl font-bold mt-4">Total: ₹{total.toLocaleString("en-IN")}</div><Link to="/checkout" className="block text-right mt-3"><span className="bg-brand text-white px-5 py-2.5 rounded inline-block">Proceed to checkout</span></Link>
    </div>
  );
}
