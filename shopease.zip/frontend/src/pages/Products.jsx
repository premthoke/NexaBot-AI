import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import api from "../services/api";
import ProductCard from "../components/ProductCard";
export default function Products() {
  const [sp, setSp] = useSearchParams(); const [data, setData] = useState({ items: [], total: 0 });
  useEffect(() => { api.get("/api/products", { params: Object.fromEntries(sp) }).then((r) => setData(r.data)); }, [sp]);
  const set = (k, v) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); setSp(n); };
  return (
    <div className="grid md:grid-cols-[220px_1fr] gap-6">
      <aside className="bg-white border rounded-lg p-4 space-y-3 h-fit text-sm">
        <h3 className="font-semibold">Filters</h3>
        <select value={sp.get("category") || ""} onChange={(e) => set("category", e.target.value)} className="w-full border rounded p-1.5">
          <option value="">All categories</option>{["Electronics", "Fashion", "Grocery", "Mobiles", "Laptops", "Home", "Books", "Appliances"].map((c) => <option key={c}>{c}</option>)}</select>
        <select value={sp.get("min_rating") || ""} onChange={(e) => set("min_rating", e.target.value)} className="w-full border rounded p-1.5">
          <option value="">Any rating</option><option value="4">4★ & up</option><option value="3">3★ & up</option></select>
        <input type="number" placeholder="Max price" defaultValue={sp.get("max_price") || ""} onBlur={(e) => set("max_price", e.target.value)} className="w-full border rounded p-1.5" />
      </aside>
      <div>
        <div className="flex justify-between items-center mb-3"><span className="text-sm text-stone-600">{data.total} results</span>
          <select value={sp.get("sort") || "relevance"} onChange={(e) => set("sort", e.target.value)} className="border rounded p-1.5 text-sm">
            <option value="relevance">Relevance</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option><option value="rating">Top rated</option><option value="newest">Newest</option></select></div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{data.items.map((p) => <ProductCard key={p.product_id} p={p} />)}</div>
      </div>
    </div>
  );
}
