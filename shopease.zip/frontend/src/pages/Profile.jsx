import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api";
export default function Profile() {
  const [u, setU] = useState(null); const [msg, setMsg] = useState(""); const nav = useNavigate();
  useEffect(() => { api.get("/api/auth/me").then((r) => setU(r.data)).catch(() => nav("/login")); }, [nav]);
  if (!u) return <p>Loading…</p>;
  const save = async (e) => { e.preventDefault(); await api.put("/api/auth/me", { name: u.name, phone: u.phone || "" }); setMsg("Profile saved"); };
  const logout = () => { localStorage.removeItem("token"); nav("/login"); };
  return (
    <form onSubmit={save} className="max-w-sm mx-auto bg-white border rounded-lg p-6 space-y-3">
      <h1 className="text-xl font-semibold">My profile</h1><p className="text-sm text-stone-500">{u.email}</p>
      <input value={u.name} onChange={(e) => setU({ ...u, name: e.target.value })} className="w-full border rounded p-2" placeholder="Name" />
      <input value={u.phone || ""} onChange={(e) => setU({ ...u, phone: e.target.value })} className="w-full border rounded p-2" placeholder="Phone" />
      {msg && <p className="text-green-700 text-sm">{msg}</p>}
      <button className="w-full bg-brand text-white rounded p-2">Save changes</button>
      {u.role === "admin" && <Link to="/admin" className="block text-center text-brand">Open admin panel</Link>}
      <button type="button" onClick={logout} className="w-full border rounded p-2">Log out</button>
    </form>
  );
}
