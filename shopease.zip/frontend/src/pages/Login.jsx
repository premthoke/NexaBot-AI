import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
export default function Login() {
  const [mode, setMode] = useState("login"); const [f, setF] = useState({ name: "", email: "", password: "" }); const [err, setErr] = useState(""); const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try { const { data } = await api.post(`/api/auth/${mode}`, f); localStorage.setItem("token", data.token); nav("/"); }
    catch (x) { setErr(x.response?.data?.detail || "Something went wrong"); }
  };
  const inp = (k, ph, type = "text") => <input type={type} placeholder={ph} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} className="w-full border rounded p-2" required />;
  return (
    <form onSubmit={submit} className="max-w-sm mx-auto bg-white border rounded-lg p-6 space-y-3">
      <h1 className="text-xl font-semibold">{mode === "login" ? "Log in" : "Create account"}</h1>
      {mode === "register" && inp("name", "Full name")}{inp("email", "Email", "email")}{inp("password", "Password", "password")}
      {err && <p className="text-red-600 text-sm">{err}</p>}
      <button className="w-full bg-brand text-white rounded p-2">{mode === "login" ? "Log in" : "Register"}</button>
      <button type="button" onClick={() => setMode(mode === "login" ? "register" : "login")} className="text-sm text-brand">{mode === "login" ? "New here? Create an account" : "Have an account? Log in"}</button>
    </form>
  );
}
