import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api from "../services/api";
export default function Support() {
  const { slug } = useParams(); const [topics, setTopics] = useState([]); const [doc, setDoc] = useState(null);
  useEffect(() => { api.get("/api/support").then((r) => setTopics(r.data)); }, []);
  useEffect(() => { setDoc(null); if (slug) api.get(`/api/support/${slug}`).then((r) => setDoc(r.data)); }, [slug]);
  return (
    <div className="grid md:grid-cols-[240px_1fr] gap-6">
      <nav className="bg-white border rounded-lg p-3 h-fit">{topics.map((t) => <Link key={t.slug} to={`/support/${t.slug}`} className={`block px-2 py-1.5 rounded ${t.slug === slug ? "bg-stone-100 font-medium" : ""}`}>{t.title}</Link>)}</nav>
      <article>{doc ? <><h1 className="text-2xl font-semibold mb-3">{doc.title}</h1>{doc.sections.map((s) => <section key={s.heading} className="mb-4"><h2 className="font-medium">{s.heading}</h2><p className="text-stone-700">{s.content}</p></section>)}</> : <p>Select a topic to see details.</p>}</article>
    </div>
  );
}
