import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";
import ProductCard from "../components/ProductCard";
const Row = ({ title, tag }) => {
  const [items, setItems] = useState([]);
  useEffect(() => { api.get("/api/products", { params: { tag, limit: 6 } }).then((r) => setItems(r.data.items)); }, [tag]);
  return <section className="mt-8"><h2 className="text-xl font-semibold mb-3">{title}</h2><div className="grid grid-cols-2 md:grid-cols-6 gap-3">{items.map((p) => <ProductCard key={p.product_id} p={p} />)}</div></section>;
};
export default function Home() {
  const [cats, setCats] = useState([]); const [recent, setRecent] = useState([]);
  useEffect(() => { api.get("/api/categories").then((r) => setCats(r.data)); setRecent(JSON.parse(localStorage.getItem("recent") || "[]")); }, []);
  return (
    <div>
      <div className="bg-brand text-white rounded-xl p-10 md:p-16"><h1 className="text-3xl md:text-5xl font-bold max-w-xl">Everyday essentials, delivered in days.</h1>
        <Link to="/products" className="inline-block mt-6 bg-accent text-stone-900 font-semibold px-5 py-2.5 rounded">Shop all products</Link></div>
      <div className="flex gap-2 flex-wrap mt-6">{cats.map((c) => <Link key={c.name} to={`/products?category=${c.name}`} className="bg-white border rounded-full px-4 py-1.5 hover:border-brand">{c.name}</Link>)}</div>
      <Row title="Trending products" tag="trending" /><Row title="Best sellers" tag="bestseller" /><Row title="Recommended for you" tag="recommended" />
      {recent.length > 0 && <section className="mt-8"><h2 className="text-xl font-semibold mb-3">Recently viewed</h2><div className="grid grid-cols-2 md:grid-cols-6 gap-3">{recent.map((p) => <ProductCard key={p.product_id} p={p} />)}</div></section>}
    </div>
  );
}
