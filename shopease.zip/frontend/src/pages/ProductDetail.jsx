import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../services/api";
import { useCart } from "../services/cart";
import ProductCard from "../components/ProductCard";
export default function ProductDetail() {
  const { id } = useParams(); const [p, setP] = useState(null); const [img, setImg] = useState(0); const { add } = useCart(); const nav = useNavigate();
  useEffect(() => {
    api.get(`/api/products/${id}`).then((r) => {
      setP(r.data); setImg(0);
      const prev = JSON.parse(localStorage.getItem("recent") || "[]").filter((x) => x.product_id !== id);
      localStorage.setItem("recent", JSON.stringify([r.data, ...prev].slice(0, 6).map(({ similar, ...x }) => x)));
    });
  }, [id]);
  if (!p) return <p>Loading…</p>;
  return (
    <div>
      <div className="grid md:grid-cols-2 gap-8">
        <div><img src={p.images[img]} alt={p.title} className="w-full rounded-lg" />
          <div className="flex gap-2 mt-2">{p.images.map((s, i) => <img key={i} src={s} onClick={() => setImg(i)} className={`w-16 h-16 rounded cursor-pointer border-2 ${i === img ? "border-brand" : "border-transparent"}`} />)}</div></div>
        <div>
          <h1 className="text-2xl font-semibold">{p.title}</h1><p className="text-sm text-stone-500">{p.brand} · Sold by {p.seller}</p>
          <p className="mt-2">{p.rating} ★ ({p.reviews.length} reviews)</p>
          <p className="mt-3 text-3xl font-bold">₹{p.price.toLocaleString("en-IN")} {p.discount > 0 && <span className="text-base font-normal text-stone-500"><s>₹{p.mrp}</s> <span className="text-green-700">{p.discount}% off</span></span>}</p>
          <p className="mt-3">{p.description}</p>
          <p className="mt-2 text-sm">Delivery in {p.shipping_time} · Warranty: {p.warranty} · {p.stock > 0 ? `${p.stock} in stock` : "Out of stock"}</p>
          <div className="mt-5 flex gap-3">
            <button disabled={!p.stock} onClick={() => add(p)} className="bg-accent px-5 py-2.5 rounded font-semibold disabled:opacity-50">Add to cart</button>
            <button disabled={!p.stock} onClick={() => { add(p); nav("/cart"); }} className="bg-brand text-white px-5 py-2.5 rounded font-semibold disabled:opacity-50">Buy now</button>
            <button onClick={() => { const w = JSON.parse(localStorage.getItem("wishlist") || "[]"); localStorage.setItem("wishlist", JSON.stringify([...new Set([...w, p.product_id])])); }} className="border px-4 rounded">♡ Wishlist</button>
          </div>
          <h2 className="mt-6 font-semibold">Specifications</h2>
          <table className="text-sm mt-1"><tbody>{Object.entries(p.specifications).map(([k, v]) => <tr key={k}><td className="pr-6 py-0.5 text-stone-500">{k}</td><td>{v}</td></tr>)}</tbody></table>
        </div>
      </div>
      <h2 className="mt-8 text-xl font-semibold">Reviews</h2>
      <ul className="mt-2 space-y-2">{p.reviews.map((r, i) => <li key={i} className="bg-white border rounded p-3 text-sm"><b>{r.user}</b> · {r.rating} ★<p>{r.comment}</p></li>)}</ul>
      <h2 className="mt-8 text-xl font-semibold mb-3">Similar products</h2>
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">{p.similar.slice(0, 6).map((s) => <ProductCard key={s.product_id} p={s} />)}</div>
    </div>
  );
}
