import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import { useCart } from "../services/cart";
export default function Checkout() {
  const { items, total, clear } = useCart(); const nav = useNavigate(); const [err, setErr] = useState("");
  const [a, setA] = useState({ name: "", line1: "", city: "", pincode: "", phone: "" }); const [pay, setPay] = useState("UPI");
  const delivery = total >= 499 ? 0 : 40;
  const place = async (e) => {
    e.preventDefault();
    try { await api.post("/api/orders", { items: items.map((i) => ({ product_id: i.product_id, quantity: i.quantity })), address: a, payment_method: pay }); clear(); nav("/orders"); }
    catch (x) { setErr(x.response?.status === 401 ? "Please log in first." : x.response?.data?.detail || "Could not place order"); }
  };
  if (!items.length) return <p>Your cart is empty.</p>;
  return (
    <form onSubmit={place} className="grid md:grid-cols-[1fr_320px] gap-6 max-w-4xl">
      <div className="bg-white border rounded-lg p-5 space-y-3">
        <h1 className="text-xl font-semibold">Delivery address</h1>
        {[["name", "Full name"], ["line1", "Address"], ["city", "City"], ["pincode", "Pincode"], ["phone", "Phone"]].map(([k, l]) =>
          <input key={k} required placeholder={l} value={a[k]} onChange={(e) => setA({ ...a, [k]: e.target.value })} className="w-full border rounded p-2" />)}
        <h2 className="font-semibold pt-2">Payment method</h2>
        {["UPI", "Card", "Net Banking", "COD"].map((m) => <label key={m} className="block"><input type="radio" checked={pay === m} onChange={() => setPay(m)} /> {m === "COD" ? "Cash on Delivery" : m}</label>)}
      </div>
      <div className="bg-white border rounded-lg p-5 h-fit">
        <h2 className="font-semibold mb-2">Order summary</h2>
        {items.map((i) => <div key={i.product_id} className="flex justify-between text-sm"><span className="truncate pr-2">{i.title} × {i.quantity}</span><span>₹{(i.price * i.quantity).toLocaleString("en-IN")}</span></div>)}
        <div className="flex justify-between text-sm mt-2"><span>Delivery</span><span>{delivery ? `₹${delivery}` : "Free"}</span></div>
        <div className="flex justify-between font-bold mt-2 border-t pt-2"><span>Total</span><span>₹{(total + delivery).toLocaleString("en-IN")}</span></div>
        {err && <p className="text-red-600 text-sm mt-2">{err}</p>}
        <button className="w-full bg-accent font-semibold rounded p-2.5 mt-3">Place order</button>
      </div>
    </form>
  );
}
