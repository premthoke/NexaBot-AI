import { useEffect, useState } from "react";
import api from "../services/api";
const blank = { title: "", category: "Electronics", brand: "", price: "", stock: "" };
export default function Admin() {
  const [tab, setTab] = useState("products"); const [rows, setRows] = useState([]); const [f, setF] = useState(blank); const [cat, setCat] = useState(""); const [err, setErr] = useState("");
  const load = () => {
    const url = { products: "/api/products?limit=100", users: "/api/admin/users", orders: "/api/admin/orders" }[tab];
    api.get(url).then((r) => setRows(r.data.items || r.data)).catch(() => setErr("Admin access required. Log in as admin@shopease.com."));
  };
  useEffect(load, [tab]);
  const add = async (e) => {
    e.preventDefault();
    await api.post("/api/admin/products", { ...f, price: +f.price, mrp: +f.price, discount: 0, stock: +f.stock, description: f.title, images: ["https://picsum.photos/seed/" + f.title + "/600/600"],
      rating: 0, reviews: [], specifications: {}, shipping_time: "3-5 business days", warranty: "1 year", seller: "ShopEase Retail", tags: [] });
    setF(blank); load();
  };
  const edit = async (p) => { const price = prompt("New price", p.price); if (price) { await api.put(`/api/admin/products/${p.product_id}`, { price: +price }); load(); } };
  const del = async (id) => { if (confirm("Delete this product?")) { await api.delete(`/api/admin/products/${id}`); load(); } };
  if (err) return <p>{err}</p>;
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-3">Admin panel</h1>
      <div className="flex gap-2 mb-4">{["products", "users", "orders"].map((t) => <button key={t} onClick={() => setTab(t)} className={`px-4 py-1.5 rounded border ${tab === t ? "bg-brand text-white" : "bg-white"}`}>{t}</button>)}</div>
      {tab === "products" && <>
        <form onSubmit={add} className="grid md:grid-cols-6 gap-2 mb-3">
          {["title", "brand", "price", "stock"].map((k) => <input key={k} required placeholder={k} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} className="border rounded p-2" />)}
          <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} className="border rounded p-2">{["Electronics", "Fashion", "Grocery", "Mobiles", "Laptops", "Home", "Books", "Appliances"].map((c) => <option key={c}>{c}</option>)}</select>
          <button className="bg-accent rounded font-semibold">Add product</button></form>
        <form onSubmit={async (e) => { e.preventDefault(); await api.post("/api/admin/categories", { name: cat }); setCat(""); }} className="flex gap-2 mb-4">
          <input value={cat} onChange={(e) => setCat(e.target.value)} placeholder="New category name" className="border rounded p-2" required /><button className="border rounded px-3">Add category</button></form></>}
      <div className="overflow-x-auto bg-white border rounded"><table className="w-full text-sm">
        <tbody>{rows.map((r, i) => tab === "products"
          ? <tr key={i} className="border-b"><td className="p-2">{r.product_id}</td><td>{r.title}</td><td>{r.category}</td><td>₹{r.price}</td><td>{r.stock}</td><td><button onClick={() => edit(r)} className="text-brand mr-3">Update price</button><button onClick={() => del(r.product_id)} className="text-red-600">Delete</button></td></tr>
          : tab === "users" ? <tr key={i} className="border-b"><td className="p-2">{r.user_id}</td><td>{r.name}</td><td>{r.email}</td><td>{r.role}</td></tr>
          : <tr key={i} className="border-b"><td className="p-2">{r.order_id}</td><td>{r.user_id}</td><td>₹{r.total}</td><td>{r.payment_status}</td><td>{r.shipping_status}</td></tr>)}</tbody></table></div>
    </div>
  );
}
