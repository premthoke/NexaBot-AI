import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";
const STEPS = ["processing", "shipped", "out_for_delivery", "delivered"];
function Order({ o }) {
  const at = Math.max(0, STEPS.indexOf(o.shipping_status));
  return (
    <div className="bg-white border rounded-lg p-4 mb-3">
      <div className="flex flex-wrap justify-between text-sm"><b>{o.order_id}</b><span>Tracking: {o.tracking_id} · {o.courier_partner}</span></div>
      <div className="text-sm text-stone-600">Payment: {o.payment_status} · Delivery date: {o.delivery_date} · Total ₹{o.total.toLocaleString("en-IN")}</div>
      <ul className="text-sm my-2 list-disc pl-5">{o.products.map((p) => <li key={p.product_id}><Link className="text-brand" to={`/product/${p.product_id}`}>{p.title}</Link> × {p.quantity}</li>)}</ul>
      <div className="flex gap-1 mt-2">{STEPS.map((s, i) => <div key={s} className="flex-1"><div className={`h-1.5 rounded ${i <= at ? "bg-brand" : "bg-stone-200"}`} /><div className="text-xs mt-1">{s.replaceAll("_", " ")}</div></div>)}</div>
    </div>
  );
}
export default function Orders() {
  const [orders, setOrders] = useState(null); const [err, setErr] = useState("");
  useEffect(() => { api.get("/api/orders").then((r) => setOrders(r.data)).catch(() => setErr("Please log in to see your orders.")); }, []);
  if (err) return <p>{err} <Link to="/login" className="text-brand underline">Log in</Link></p>;
  if (!orders) return <p>Loading…</p>;
  const cur = orders.filter((o) => o.shipping_status !== "delivered"), prev = orders.filter((o) => o.shipping_status === "delivered");
  return (
    <div className="max-w-3xl"><h1 className="text-2xl font-semibold mb-3">Current orders</h1>{cur.length ? cur.map((o) => <Order key={o.order_id} o={o} />) : <p className="mb-4">No current orders.</p>}
      <h1 className="text-2xl font-semibold my-3">Previous orders</h1>{prev.length ? prev.map((o) => <Order key={o.order_id} o={o} />) : <p>No previous orders.</p>}</div>
  );
}
