import { Link } from "react-router-dom";
export default function ProductCard({ p }) {
  return (
    <Link to={`/product/${p.product_id}`} className="bg-white rounded-lg border border-stone-200 p-3 block hover:border-brand">
      <img src={p.images[0]} alt={p.title} className="w-full aspect-square object-cover rounded" loading="lazy" />
      <h3 className="mt-2 text-sm font-medium line-clamp-2">{p.title}</h3>
      <div className="text-xs text-stone-500">{p.rating} ★ · {p.brand}</div>
      <div className="mt-1"><span className="font-semibold">₹{p.price.toLocaleString("en-IN")}</span>
        {p.discount > 0 && <span className="ml-2 text-xs text-green-700">{p.discount}% off</span>}</div>
    </Link>
  );
}
