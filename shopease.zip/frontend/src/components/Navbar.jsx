import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api";
import { useCart } from "../services/cart";
export default function Navbar() {
  const [q, setQ] = useState(""); const [sugg, setSugg] = useState([]); const nav = useNavigate(); const { count } = useCart();
  useEffect(() => {
    if (q.length < 2) return setSugg([]);
    const t = setTimeout(() => api.get("/api/products/suggest", { params: { q } }).then((r) => setSugg(r.data)), 250);
    return () => clearTimeout(t);
  }, [q]);
  const go = (e) => { e.preventDefault(); setSugg([]); nav(`/products?q=${encodeURIComponent(q)}`); };
  return (
    <header className="bg-brand text-white sticky top-0 z-40">
      <div className="max-w-7xl mx-auto flex items-center gap-4 p-3">
        <Link to="/" className="text-xl font-bold">ShopEase</Link>
        <form onSubmit={go} className="relative flex-1">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products, brands and categories" className="w-full rounded px-3 py-2 text-stone-900" />
          {sugg.length > 0 && <ul className="absolute w-full bg-white text-stone-900 rounded shadow mt-1">
            {sugg.map((s) => <li key={s.product_id}><Link onClick={() => { setSugg([]); setQ(""); }} to={`/product/${s.product_id}`} className="block px-3 py-2 hover:bg-stone-100">{s.title} <span className="text-xs text-stone-500">in {s.category}</span></Link></li>)}
          </ul>}
        </form>
        <Link to="/orders">Orders</Link><Link to="/support">Help</Link><Link to={localStorage.getItem("token") ? "/profile" : "/login"}>Account</Link><Link to="/cart">Cart ({count})</Link>
      </div>
    </header>
  );
}
