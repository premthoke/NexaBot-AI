import { useState } from "react";
import api from "../services/api";
const START = ["Track my latest order", "Return policy", "Delivery charges", "Payment methods", "Contact support"];
export default function ChatWidget() {
  const [open, setOpen] = useState(false); const [text, setText] = useState(""); const [sid, setSid] = useState(null); const [opts, setOpts] = useState(START);
  const [msgs, setMsgs] = useState([{ from: "bot", text: "Hi! I'm the ShopEase assistant. Ask me anything or pick an option below." }]);
  const ask = async (m) => {
    if (!m.trim()) return; setText(""); setMsgs((s) => [...s, { from: "user", text: m }]);
    try { const { data } = await api.post("/chat", { message: m, session_id: sid }); setSid(data.session_id); setOpts(data.options || []); setMsgs((s) => [...s, { from: "bot", text: data.reply }]); }
    catch { setMsgs((s) => [...s, { from: "bot", text: "Sorry, support is unavailable right now." }]); }
  };
  return (
    <div className="fixed bottom-5 right-5 z-50">
      {open && <div className="w-80 h-[28rem] bg-white rounded-lg shadow-xl border flex flex-col mb-3">
        <div className="bg-brand text-white px-3 py-2 rounded-t-lg">ShopEase Support</div>
        <div className="flex-1 overflow-y-auto p-3 space-y-2 text-sm whitespace-pre-line">
          {msgs.map((m, i) => <div key={i} className={m.from === "user" ? "text-right" : ""}><span className={`inline-block px-3 py-1.5 rounded-lg text-left ${m.from === "user" ? "bg-brand text-white" : "bg-stone-100"}`}>{m.text}</span></div>)}
        </div>
        <div className="flex flex-wrap gap-1 px-2 pb-1">{opts.map((o) => <button key={o} onClick={() => ask(o)} className="text-xs border border-brand text-brand rounded-full px-2 py-0.5 hover:bg-teal-50">{o}</button>)}</div>
        <form onSubmit={(e) => { e.preventDefault(); ask(text); }} className="flex border-t"><input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message" className="flex-1 px-3 py-2 outline-none" /><button className="px-3 text-brand font-medium">Send</button></form>
      </div>}
      <button onClick={() => setOpen(!open)} aria-label="Open support chat" className="w-14 h-14 rounded-full bg-accent shadow-lg text-2xl ml-auto block">💬</button>
    </div>
  );
}
