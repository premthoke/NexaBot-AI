"""Run: python seed.py  -> writes policy JSON files and seeds MongoDB (150+ products, users, orders)."""
import asyncio, json, random, pathlib, datetime as dt
from app.db import db
from app.security import hash_pw
random.seed(7)
CATS = {
 "Electronics": (["Sony", "boAt", "JBL", "Philips"], ["Headphones", "Bluetooth Speaker", "Smartwatch", "Power Bank", "Webcam"]),
 "Fashion": (["Levis", "Puma", "H&M", "Nike"], ["T-Shirt", "Jeans", "Sneakers", "Jacket", "Hoodie"]),
 "Grocery": (["Tata", "Aashirvaad", "Amul", "Fortune"], ["Basmati Rice 5kg", "Atta 10kg", "Cooking Oil 5L", "Green Tea", "Almonds 1kg"]),
 "Mobiles": (["Samsung", "Redmi", "OnePlus", "Apple"], ["5G Smartphone", "Pro Max Phone", "Lite Phone", "Ultra Phone"]),
 "Laptops": (["Dell", "HP", "Lenovo", "ASUS"], ["Ultrabook", "Gaming Laptop", "Business Laptop", "2-in-1 Laptop"]),
 "Home": (["Wakefit", "Godrej", "Solimo", "Cello"], ["Bedsheet Set", "Study Table", "Storage Box", "LED Lamp", "Curtains"]),
 "Books": (["Penguin", "HarperCollins", "Rupa", "Scholastic"], ["Fiction Novel", "Self-Help Guide", "Coding Handbook", "Cookbook", "History Book"]),
 "Appliances": (["LG", "Whirlpool", "Bosch", "Havells"], ["Refrigerator", "Washing Machine", "Microwave Oven", "Air Fryer", "Mixer Grinder"]),
}
RANGE = {"Electronics": (999, 15999), "Fashion": (499, 4999), "Grocery": (99, 1499), "Mobiles": (8999, 79999),
         "Laptops": (29999, 129999), "Home": (399, 12999), "Books": (149, 799), "Appliances": (2499, 45999)}
TAGS = ["trending", "bestseller", "recommended"]
SELLERS = ["ShopEase Retail", "Prime Traders", "Urban Mart", "TechHub India"]

def products():
    out, n = [], 1
    for cat, (brands, nouns) in CATS.items():
        for i in range(19):
            brand, noun = random.choice(brands), random.choice(nouns)
            lo, hi = RANGE[cat]; mrp = round(random.randint(lo, hi), -1); disc = random.choice([0, 5, 10, 15, 20, 30, 40])
            pid = f"P{n:04d}"; n += 1
            out.append({"product_id": pid, "title": f"{brand} {noun} {random.choice(['Plus', 'X', 'Neo', 'Classic', 'Max'])} {i+1}",
              "description": f"{brand} {noun.lower()} built for everyday use with dependable quality and great value.",
              "category": cat, "brand": brand, "mrp": mrp, "discount": disc, "price": round(mrp * (100 - disc) / 100, 2),
              "stock": random.randint(0, 200), "rating": round(random.uniform(3.2, 4.9), 1),
              "specifications": {"Model": f"{brand[:3].upper()}-{random.randint(100, 999)}", "Color": random.choice(["Black", "Blue", "Grey", "Red", "White"]),
                                 "Weight": f"{random.randint(100, 3000)} g", "Country of Origin": "India"},
              "images": [f"https://picsum.photos/seed/{pid}-{k}/600/600" for k in range(3)],
              "reviews": [{"user": random.choice(["Aarav", "Diya", "Rohan", "Meera", "Kabir"]), "rating": random.randint(3, 5),
                           "comment": random.choice(["Great value for money.", "Good quality, fast delivery.", "Works as described.", "Packaging could be better."])} for _ in range(3)],
              "shipping_time": f"{random.randint(2, 7)} business days", "warranty": random.choice(["No warranty", "6 months", "1 year", "2 years"]),
              "seller": random.choice(SELLERS), "tags": [random.choice(TAGS)], "created_at": dt.datetime.utcnow() - dt.timedelta(days=random.randint(0, 300))})
    return out


CURATED = [  # (category, brand, title, mrp, discount, specs, description)
 ("Electronics","Sony","Sony WH-CH720N Wireless Noise Cancelling Headphones",14990,33,{"Battery":"35 hrs","Connectivity":"Bluetooth 5.2","Weight":"192 g"},"Lightweight over-ear headphones with active noise cancelling and multipoint pairing."),
 ("Electronics","boAt","boAt Stone 1200 Portable Bluetooth Speaker 14W",5990,68,{"Output":"14 W","Playback":"9 hrs","Water Resistance":"IPX7"},"Rugged waterproof speaker with punchy bass and 9 hours of playback."),
 ("Electronics","Anker","Anker PowerCore 20000mAh Power Bank",4999,40,{"Capacity":"20000 mAh","Ports":"2x USB-A, 1x USB-C","Charging":"22.5 W fast charge"},"High-capacity power bank that charges a phone up to five times."),
 ("Electronics","Noise","Noise ColorFit Pro 5 Smartwatch 1.85 inch AMOLED",9999,70,{"Display":"1.85 inch AMOLED","Battery":"7 days","Features":"Bluetooth calling, SpO2, heart rate"},"Bright AMOLED smartwatch with calling, health tracking and 100+ sports modes."),
 ("Fashion","Levis","Levi's Men's 511 Slim Fit Stretch Jeans",3999,35,{"Fit":"Slim","Fabric":"98% cotton, 2% elastane","Rise":"Mid"},"Classic slim-fit jeans with comfortable stretch for all-day wear."),
 ("Fashion","Puma","Puma Men's Softride Running Shoes",4499,45,{"Sole":"Rubber","Closure":"Lace-up","Use":"Running"},"Cushioned running shoes with a breathable mesh upper."),
 ("Fashion","Allen Solly","Allen Solly Men's Regular Fit Cotton Shirt",1999,50,{"Fabric":"100% cotton","Fit":"Regular","Sleeve":"Full"},"Smart, breathable cotton shirt suitable for office and casual wear."),
 ("Fashion","W","W Women's Printed Anarkali Kurta",2499,40,{"Fabric":"Rayon","Length":"Calf","Care":"Machine wash"},"Flowy printed kurta in soft rayon with a flattering flared cut."),
 ("Grocery","Aashirvaad","Aashirvaad Shudh Chakki Atta 10 kg",560,10,{"Weight":"10 kg","Type":"Whole wheat","Shelf Life":"4 months"},"Stone-ground whole wheat atta for soft, fluffy rotis."),
 ("Grocery","Tata Tea","Tata Tea Gold 1 kg",620,12,{"Weight":"1 kg","Type":"Black tea leaves","Origin":"Assam"},"Rich, aromatic blend with long-leaf Assam tea and a touch of aged tea."),
 ("Grocery","Fortune","Fortune Sunlite Refined Sunflower Oil 5 L",950,15,{"Volume":"5 L","Type":"Refined sunflower oil","Pack":"Jar"},"Light, healthy cooking oil suitable for everyday Indian cooking."),
 ("Grocery","Happilo","Happilo Premium California Almonds 1 kg",1499,40,{"Weight":"1 kg","Type":"Raw almonds","Origin":"California"},"Crunchy, nutrient-rich almonds, vacuum packed to stay fresh."),
 ("Mobiles","Samsung","Samsung Galaxy S24 5G (8GB RAM, 256GB)",79999,32,{"Display":"6.2 inch Dynamic AMOLED","Camera":"50 MP triple","Battery":"4000 mAh"},"Flagship AI-powered smartphone with a brilliant display and pro-grade camera."),
 ("Mobiles","OnePlus","OnePlus Nord CE4 5G (8GB RAM, 128GB)",26999,15,{"Display":"6.7 inch AMOLED 120Hz","Battery":"5500 mAh","Charging":"100 W SUPERVOOC"},"Fast, smooth mid-range 5G phone with a huge battery."),
 ("Mobiles","Redmi","Redmi Note 13 Pro 5G (8GB RAM, 256GB)",29999,30,{"Display":"6.67 inch AMOLED","Camera":"200 MP","Battery":"5100 mAh"},"200 MP camera phone with a stunning curved display."),
 ("Mobiles","Apple","Apple iPhone 15 (128GB)",79900,12,{"Chip":"A16 Bionic","Display":"6.1 inch Super Retina XDR","Camera":"48 MP main"},"iPhone 15 with Dynamic Island, USB-C and a 48 MP camera."),
 ("Laptops","HP","HP Pavilion 15 (Intel Core i5 13th Gen, 16GB, 512GB SSD)",74999,28,{"Processor":"Intel Core i5-1335U","RAM":"16 GB","Storage":"512 GB SSD"},"Everyday laptop with a fast SSD and a crisp Full HD anti-glare display."),
 ("Laptops","Lenovo","Lenovo IdeaPad Slim 3 (Ryzen 5 7520U, 8GB, 512GB SSD)",52990,32,{"Processor":"AMD Ryzen 5 7520U","RAM":"8 GB","Display":"15.6 inch FHD"},"Slim, light laptop built for students and remote work."),
 ("Laptops","ASUS","ASUS TUF Gaming F15 (Core i7, RTX 4060, 16GB, 512GB)",119990,25,{"Processor":"Intel Core i7-13620H","GPU":"NVIDIA RTX 4060","Display":"15.6 inch 144Hz"},"Military-grade durable gaming laptop with a 144 Hz display."),
 ("Laptops","Apple","Apple MacBook Air M2 (13-inch, 8GB, 256GB)",114900,14,{"Chip":"Apple M2","Battery":"Up to 18 hrs","Display":"13.6 inch Liquid Retina"},"Thin, fanless and fast, with all-day battery life."),
 ("Home","Wakefit","Wakefit Orthopedic Memory Foam Mattress (Queen)",21999,55,{"Size":"78x60x6 inches","Type":"Memory foam","Warranty":"10 years"},"Orthopedic memory foam mattress that supports your back through the night."),
 ("Home","Philips","Philips 9W LED Bulb (Pack of 6)",900,45,{"Wattage":"9 W","Base":"B22","Colour":"Cool daylight"},"Energy-efficient LED bulbs with a long life of up to 15,000 hours."),
 ("Home","Cello","Cello Opalware Dinner Set 18 Pieces",3299,42,{"Pieces":"18","Material":"Opalware","Microwave Safe":"Yes"},"Elegant, chip-resistant dinner set for a family of six."),
 ("Home","Solimo","Solimo Microfibre Double Bed Comforter",2999,60,{"Size":"Double","Material":"Microfibre","Care":"Machine wash"},"Soft, lightweight comforter that keeps you warm without the bulk."),
 ("Books","Penguin","Atomic Habits by James Clear (Paperback)",799,35,{"Author":"James Clear","Pages":"320","Language":"English"},"A practical, proven framework for building good habits and breaking bad ones."),
 ("Books","Jaico","The Psychology of Money by Morgan Housel",399,20,{"Author":"Morgan Housel","Pages":"252","Language":"English"},"Timeless lessons on wealth, greed and happiness."),
 ("Books","Manjul","Rich Dad Poor Dad by Robert Kiyosaki",499,30,{"Author":"Robert T. Kiyosaki","Pages":"336","Language":"English"},"The classic personal finance book that challenges what you know about money."),
 ("Books","Prentice Hall","Clean Code by Robert C. Martin",4299,45,{"Author":"Robert C. Martin","Pages":"464","Language":"English"},"A handbook of agile software craftsmanship for writing readable, maintainable code."),
 ("Appliances","LG","LG 7 kg 5 Star Fully Automatic Front Load Washing Machine",38990,30,{"Capacity":"7 kg","Energy Rating":"5 Star","Type":"Front load"},"Inverter direct-drive washer with steam wash and 6 motion technology."),
 ("Appliances","Philips","Philips HD9252 Air Fryer 4.1 L",9995,35,{"Capacity":"4.1 L","Power":"1400 W","Technology":"Rapid Air"},"Fry with up to 90% less fat using rapid air technology."),
 ("Appliances","Bosch","Bosch 25 L Convection Microwave Oven",13990,28,{"Capacity":"25 L","Type":"Convection","Power":"900 W"},"Bake, grill and reheat with 10 auto-cook menus."),
 ("Appliances","Havells","Havells 1200mm Ventilation Ceiling Fan",3200,30,{"Sweep":"1200 mm","Speed":"380 RPM","Warranty":"2 years"},"Energy-saving ceiling fan with a smooth, silent motor."),
]

def curated_products(start):
    out = []
    for k, (cat, brand, title, mrp, disc, specs, desc) in enumerate(CURATED):
        pid = f"P{start + k:04d}"
        out.append({"product_id": pid, "title": title, "description": desc, "category": cat, "brand": brand, "mrp": mrp, "discount": disc,
          "price": round(mrp * (100 - disc) / 100, 2), "stock": random.randint(15, 250), "rating": round(random.uniform(4.0, 4.8), 1),
          "specifications": specs, "images": [f"https://picsum.photos/seed/{pid}-{i}/600/600" for i in range(3)],
          "reviews": [{"user": random.choice(["Aarav", "Diya", "Rohan", "Meera", "Kabir"]), "rating": random.randint(4, 5),
                       "comment": random.choice(["Excellent quality, totally worth it.", "Arrived early and well packed.", "Exactly as described.", "Great value for money."])} for _ in range(3)],
          "shipping_time": f"{random.randint(2, 5)} business days", "warranty": random.choice(["6 months", "1 year", "2 years"]) if cat not in ("Books", "Grocery") else "No warranty",
          "seller": random.choice(SELLERS), "tags": [random.choice(TAGS)], "created_at": dt.datetime.utcnow() - dt.timedelta(days=random.randint(0, 60))})
    return out

EXTRA = {
 "faq": ("FAQ", [("How do I track my order?", "Go to My Orders and open the order to see live status and tracking ID."), ("How do I change my address?", "Address can be changed before the order ships from the order page."), ("Can I return a gift?", "Yes, within the return window with the original packaging."), ("How do I reset my password?", "Use 'Forgot password' on the login page."), ("Do you offer Cash on Delivery?", "Yes, for orders up to Rs 50,000 with a Rs 30 handling fee."), ("Are products genuine?", "Yes. All products are sold by verified sellers and brand-authorised partners."), ("Can I order without an account?", "No, you need a free ShopEase account to place orders and track them."), ("How do I contact support?", "Email support@shopease.example or call 1800-000-0000, Mon-Sat 9am-8pm IST."), ("Is there a minimum order value?", "No minimum, but delivery is free on orders of Rs 499 and above."), ("What if my payment failed but money was deducted?", "The amount is refunded automatically to your source account within 5-7 business days.")]),
 "damaged-or-wrong-item": ("Damaged or Wrong Item", [("Report within 48 hours", "Report a damaged, defective or wrong item within 48 hours of delivery from My Orders with clear photos."), ("Resolution", "You can choose a free replacement or a full refund. Pickup is arranged within 2-3 days at no cost.")]),
 "order-changes": ("Order Changes", [("Change address or phone", "You can change the delivery address or phone number until the order ships."), ("Change items", "Items can't be edited after ordering. Cancel the order (free before shipping) and place a new one.")]),
 "offers-and-coupons": ("Offers and Coupons", [("Using coupons", "Enter one coupon per order at checkout. Coupons don't apply to grocery items."), ("Bank offers", "Get 10% instant discount up to Rs 1,500 on eligible cards for orders above Rs 5,000."), ("Coupon not working", "Check the minimum order value, expiry date and eligible category.")]),
 "emi-and-payment-issues": ("EMI and Payment Issues", [("EMI", "No-cost EMI for 3-12 months is available on eligible cards for orders above Rs 3,000."), ("Failed payments", "If money is deducted but the order isn't placed, it is refunded within 5-7 business days."), ("Double charge", "Contact support with your transaction ID and we will refund the duplicate charge.")]),
 "account-and-password": ("Account and Password", [("Reset password", "Click 'Forgot password' on the login page and follow the email link."), ("Update details", "Change your name and phone in Profile."), ("Delete account", "Email support@shopease.example to request account deletion.")]),
 "invoice-and-gst": ("Invoice and GST", [("Invoice", "Your invoice is emailed after shipping and is available in My Orders."), ("GST invoice", "Enter your GSTIN at checkout to receive a GST invoice.")]),
 "loyalty-rewards": ("Loyalty Rewards", [("Earning", "Earn 1 ShopEase point for every Rs 100 spent."), ("Redeeming", "100 points equal Rs 10 off. Points expire after 12 months.")]),
 "delivery-coverage": ("Delivery Coverage", [("Pincodes", "We deliver to 19,000+ pincodes across India. Check availability on the product page."), ("Remote areas", "Remote locations may take 2-3 extra days. We do not ship internationally.")]),
 "seller-and-authenticity": ("Seller and Authenticity", [("Verified sellers", "All sellers are verified and products are sourced from brands or authorised distributors."), ("Counterfeits", "Report a suspected fake within 7 days for a full refund and investigation.")]),
 "installation-and-demo": ("Installation and Demo", [("Appliances", "Large appliances include free installation or demo by the brand within 48 hours of delivery."), ("Booking", "Book through the brand helpline printed on the warranty card.")]),
}

def policies():
    P = {
     "shipping-policy": ("Shipping Policy", [("Processing", "Orders are processed within 24 hours on business days."), ("Delivery time", "Standard delivery takes 3-7 business days; express takes 1-2 days in metro cities."), ("Tracking", "A tracking ID is emailed once your order ships and is visible under My Orders.")]),
     "return-policy": ("Return Policy", [("Window", "Most items can be returned within 10 days of delivery."), ("Conditions", "Items must be unused, with original packaging and tags."), ("Non-returnable", "Grocery, innerwear and opened software are not returnable.")]),
     "refund-policy": ("Refund Policy", [("Timeline", "Refunds are issued within 5-7 business days after the returned item passes inspection."), ("Method", "Refunds go to the original payment method; COD refunds go to your bank account or ShopEase wallet.")]),
     "cancellation-policy": ("Cancellation Policy", [("Before shipping", "Orders can be cancelled free of charge until they are shipped."), ("After shipping", "Shipped orders cannot be cancelled; refuse delivery or request a return instead.")]),
     "warranty-policy": ("Warranty Policy", [("Coverage", "Warranty period is shown on each product page and covers manufacturing defects."), ("Claims", "Contact the brand service centre with your order ID and invoice."), ("Exclusions", "Physical, liquid or unauthorised repair damage is not covered.")]),
     "payment-methods": ("Payment Methods", [("Accepted", "UPI, credit/debit cards, net banking, wallets and Cash on Delivery (orders up to Rs 50,000)."), ("Security", "All online payments are encrypted and processed by PCI-DSS compliant gateways.")]),
     "delivery-charges": ("Delivery Charges", [("Free delivery", "Free on orders of Rs 499 and above."), ("Standard fee", "Rs 40 for orders below Rs 499."), ("Express", "Rs 99 extra for express delivery."), ("COD fee", "Rs 30 handling fee for Cash on Delivery.")]),
     "faq": ("FAQ", [("How do I track my order?", "Go to My Orders and open the order to see live status and tracking ID."), ("How do I change my address?", "Address can be changed before the order ships from the order page."), ("Can I return a gift?", "Yes, within the return window with the original packaging."), ("How do I reset my password?", "Use 'Forgot password' on the login page.")]),
     "contact-us": ("Contact Us", [("Email", "support@shopease.example"), ("Phone", "1800-000-0000 (Mon-Sat, 9am-8pm IST)"), ("Address", "ShopEase Pvt Ltd, Bandra Kurla Complex, Mumbai 400051")]),
     "privacy-policy": ("Privacy Policy", [("Data we collect", "Name, contact details, addresses and order history needed to fulfil orders."), ("Use of data", "We never sell personal data. Data is used for orders, support and service improvement."), ("Your rights", "You may request access, correction or deletion of your data at any time.")]),
     "terms-and-conditions": ("Terms & Conditions", [("Use of service", "You must be 18+ or use ShopEase under adult supervision."), ("Pricing", "Prices and availability may change without notice; errors may lead to order cancellation."), ("Liability", "ShopEase is not liable for indirect losses beyond the order value.")]),
    }
    P.update(EXTRA)
    d = pathlib.Path(__file__).parent / "data" / "policies"; d.mkdir(parents=True, exist_ok=True)
    for slug, (title, secs) in P.items():
        (d / f"{slug}.json").write_text(json.dumps({"slug": slug, "title": title, "sections": [{"heading": h, "content": c} for h, c in secs]}, indent=2))

async def seed():
    policies()
    for c in ("products", "categories", "users", "orders"): await db[c].delete_many({})
    prods = products(); prods += curated_products(len(prods) + 1); await db.products.insert_many(prods)
    await db.categories.insert_many([{"name": c} for c in CATS])
    await db.users.insert_many([
        {"user_id": "U0001", "name": "Demo User", "email": "user@shopease.com", "password": hash_pw("user1234"), "role": "customer"},
        {"user_id": "U0002", "name": "Admin", "email": "admin@shopease.com", "password": hash_pw("admin1234"), "role": "admin"}])
    orders = []
    for i, (ship, pay) in enumerate([("delivered", "paid"), ("delivered", "paid"), ("shipped", "paid"), ("processing", "pending")]):
        items = random.sample(prods, 2)
        orders.append({"order_id": f"ORD1000{i}", "tracking_id": f"TRK{random.randint(10**9, 10**10-1)}", "user_id": "U0001",
          "products": [{"product_id": p["product_id"], "title": p["title"], "price": p["price"], "quantity": 1} for p in items],
          "total": round(sum(p["price"] for p in items), 2), "payment_method": "UPI" if pay == "paid" else "COD", "payment_status": pay,
          "shipping_status": ship, "courier_partner": random.choice(["Delhivery", "BlueDart", "Ecom Express"]),
          "delivery_date": (dt.date.today() + dt.timedelta(days=(-10 * (2 - i) if ship == "delivered" else 3))).isoformat(),
          "address": {"line1": "12 Marine Drive", "city": "Mumbai", "pincode": "400020"}, "created_at": dt.datetime.utcnow() - dt.timedelta(days=30 - i * 8)})
    await db.orders.insert_many(orders)
    print(f"Seeded {len(prods)} products, 2 users, {len(orders)} orders")
if __name__ == "__main__":
    asyncio.run(seed())
