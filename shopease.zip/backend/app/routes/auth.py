import uuid
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, EmailStr
from app.db import db
from app.security import hash_pw, check_pw, make_token, current_user
r = APIRouter(prefix="/api/auth", tags=["auth"])

class Register(BaseModel): name: str; email: EmailStr; password: str
class Login(BaseModel): email: EmailStr; password: str
class Profile(BaseModel): name: str | None = None; phone: str | None = None; address: dict | None = None

@r.post("/register")
async def register(b: Register):
    if await db.users.find_one({"email": b.email}): raise HTTPException(400, "Email already registered")
    uid = "U" + uuid.uuid4().hex[:8]
    await db.users.insert_one({"user_id": uid, "name": b.name, "email": b.email, "password": hash_pw(b.password), "role": "customer"})
    return {"token": make_token(uid)}

@r.post("/login")
async def login(b: Login):
    u = await db.users.find_one({"email": b.email})
    if not u or not check_pw(b.password, u["password"]): raise HTTPException(401, "Invalid credentials")
    return {"token": make_token(u["user_id"]), "role": u["role"]}

@r.get("/me")
async def me(u=Depends(current_user)): return u

@r.put("/me")
async def update_me(b: Profile, u=Depends(current_user)):
    await db.users.update_one({"user_id": u["user_id"]}, {"$set": b.model_dump(exclude_none=True)})
    return {"ok": True}
