import uuid, datetime as dt
from fastapi import APIRouter, Depends, HTTPException
from app.db import db
from app.security import admin_user
r = APIRouter(prefix="/api/admin", tags=["admin"], dependencies=[Depends(admin_user)])

@r.post("/products")
async def add(p: dict):
    p["product_id"] = "P" + uuid.uuid4().hex[:6].upper(); p["created_at"] = dt.datetime.utcnow()
    await db.products.insert_one(p); p.pop("_id"); return p

@r.put("/products/{pid}")
async def update(pid: str, p: dict):
    p.pop("_id", None); p.pop("product_id", None)
    if not (await db.products.update_one({"product_id": pid}, {"$set": p})).matched_count: raise HTTPException(404, "Not found")
    return {"ok": True}

@r.delete("/products/{pid}")
async def delete(pid: str):
    await db.products.delete_one({"product_id": pid}); return {"ok": True}

@r.post("/categories")
async def add_cat(c: dict):
    await db.categories.insert_one(dict(c)); return {"ok": True}

@r.get("/users")
async def users(): return await db.users.find({}, {"_id": 0, "password": 0}).to_list(500)

@r.get("/orders")
async def orders(): return await db.orders.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)
