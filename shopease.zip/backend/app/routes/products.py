import re
from fastapi import APIRouter, HTTPException, Query
from app.db import db
r = APIRouter(prefix="/api", tags=["catalog"])
P = {"_id": 0}

@r.get("/products")
async def products(q: str = "", category: str = "", brand: str = "", min_price: float = 0, max_price: float = 1e9,
                   min_rating: float = 0, sort: str = "relevance", limit: int = Query(24, le=100), skip: int = 0, tag: str = ""):
    f = {"price": {"$gte": min_price, "$lte": max_price}, "rating": {"$gte": min_rating}}
    if q: f["$or"] = [{k: {"$regex": re.escape(q), "$options": "i"}} for k in ("title", "brand", "category", "description")]
    if category: f["category"] = category
    if brand: f["brand"] = brand
    if tag: f["tags"] = tag
    order = {"price_asc": ("price", 1), "price_desc": ("price", -1), "rating": ("rating", -1), "newest": ("created_at", -1)}.get(sort)
    cur = db.products.find(f, P)
    if order: cur = cur.sort(*order)
    return {"total": await db.products.count_documents(f), "items": await cur.skip(skip).limit(limit).to_list(limit)}

@r.get("/products/suggest")
async def suggest(q: str):
    cur = db.products.find({"title": {"$regex": re.escape(q), "$options": "i"}}, {"_id": 0, "product_id": 1, "title": 1, "category": 1}).limit(8)
    return await cur.to_list(8)

@r.get("/products/{pid}")
async def product(pid: str):
    p = await db.products.find_one({"product_id": pid}, P)
    if not p: raise HTTPException(404, "Product not found")
    p["similar"] = await db.products.find({"category": p["category"], "product_id": {"$ne": pid}}, P).limit(8).to_list(8)
    return p

@r.get("/categories")
async def categories(): return await db.categories.find({}, P).to_list(100)
