import uuid, jwt
from fastapi import APIRouter, Depends
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from app.db import db
from app.security import bearer, SECRET
from app.chatbot.engine import answer
r = APIRouter(tags=["chat"])

class ChatIn(BaseModel):
    message: str
    session_id: str | None = None

async def optional_user(c: HTTPAuthorizationCredentials = Depends(bearer)):
    if not c: return None
    try: return await db.users.find_one({"user_id": jwt.decode(c.credentials, SECRET, ["HS256"])["sub"]}, {"_id": 0, "password": 0})
    except jwt.PyJWTError: return None

@r.post("/chat")
async def chat(b: ChatIn, user=Depends(optional_user)):
    sid = b.session_id or uuid.uuid4().hex
    out = await answer(b.message.strip()[:1000], sid, user)
    return {**out, "session_id": sid}
