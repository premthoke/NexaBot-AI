import json, pathlib
from fastapi import APIRouter, HTTPException
r = APIRouter(prefix="/api/support", tags=["support"])
D = pathlib.Path(__file__).resolve().parents[2] / "data" / "policies"

@r.get("")
def topics(): return [{"slug": f.stem, "title": json.loads(f.read_text())["title"]} for f in sorted(D.glob("*.json"))]

@r.get("/{slug}")
def topic(slug: str):
    f = D / f"{slug}.json"
    if not f.exists(): raise HTTPException(404, "Topic not found")
    return json.loads(f.read_text())
