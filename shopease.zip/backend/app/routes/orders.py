import uuid, random, datetime as dt
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.db import db
from app.security import current_user
r = APIRouter(prefix="/api/orders", tags=["orders"])

class Item(BaseModel): product_id: str; quantity: int = 1
class Checkout(BaseModel): items: list[Item]; address: dict; payment_method: str

@r.get("")
async def my_orders(u=Depends(current_user)):
    return await db.orders.find({"user_id": u["user_id"]}, {"_id": 0}).sort("created_at", -1).to_list(200)

@r.get("/{oid}")
async def order(oid: str, u=Depends(current_user)):
    o = await db.orders.find_one({"order_id": oid, "user_id": u["user_id"]}, {"_id": 0})
    if not o: raise HTTPException(404, "Order not found")
    return o

@r.post("")
async def place(b: Checkout, u=Depends(current_user)):
    lines, total = [], 0
    for i in b.items:
        p = await db.products.find_one({"product_id": i.product_id}, {"_id": 0})
        if not p or p["stock"] < i.quantity: raise HTTPException(400, f"{i.product_id} unavailable")
        lines.append({"product_id": p["product_id"], "title": p["title"], "price": p["price"], "quantity": i.quantity})
        total += p["price"] * i.quantity
        await db.products.update_one({"product_id": p["product_id"]}, {"$inc": {"stock": -i.quantity}})
    now = dt.datetime.utcnow()
    o = {"order_id": "ORD" + uuid.uuid4().hex[:8].upper(), "tracking_id": "TRK" + str(random.randint(10**9, 10**10 - 1)), "user_id": u["user_id"],
         "products": lines, "total": round(total, 2), "address": b.address, "payment_method": b.payment_method,
         "payment_status": "pending" if b.payment_method == "COD" else "paid", "shipping_status": "processing",
         "courier_partner": random.choice(["Delhivery", "BlueDart", "Ecom Express"]),
         "delivery_date": (now + dt.timedelta(days=5)).date().isoformat(), "created_at": now}
    await db.orders.insert_one(o); o.pop("_id")
    return o
