import os
URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
if URL == "mock":  # in-memory DB, no MongoDB install needed (data resets on restart)
    from mongomock_motor import AsyncMongoMockClient as Client
else:
    from motor.motor_asyncio import AsyncIOMotorClient as Client
db = Client(URL)[os.getenv("DB_NAME", "shopease")] if URL != "mock" else Client()[os.getenv("DB_NAME", "shopease")]
