import os, bcrypt, jwt, datetime as dt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.db import db
SECRET = os.getenv("JWT_SECRET", "dev-secret")
bearer = HTTPBearer(auto_error=False)

def hash_pw(p: str) -> str: return bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()
def check_pw(p: str, h: str) -> bool: return bcrypt.checkpw(p.encode(), h.encode())
def make_token(uid: str) -> str:
    return jwt.encode({"sub": uid, "exp": dt.datetime.utcnow() + dt.timedelta(days=7)}, SECRET, "HS256")

async def current_user(c: HTTPAuthorizationCredentials = Depends(bearer)):
    if not c: raise HTTPException(401, "Not authenticated")
    try: uid = jwt.decode(c.credentials, SECRET, ["HS256"])["sub"]
    except jwt.PyJWTError: raise HTTPException(401, "Invalid token")
    user = await db.users.find_one({"user_id": uid}, {"_id": 0, "password": 0})
    if not user: raise HTTPException(401, "User not found")
    return user

async def admin_user(u=Depends(current_user)):
    if u.get("role") != "admin": raise HTTPException(403, "Admin only")
    return u
