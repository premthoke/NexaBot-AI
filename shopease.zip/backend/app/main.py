from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth, products, orders, support, chat, admin
app = FastAPI(title="ShopEase API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])
for m in (auth, products, orders, support, chat, admin): app.include_router(m.r)
@app.get("/health")
def health(): return {"status": "ok"}

@app.on_event("startup")
async def auto_seed():
    from app.db import db
    if await db.products.count_documents({}) == 0:
        import seed; await seed.seed()
