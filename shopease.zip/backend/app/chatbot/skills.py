"""Personalised skills: order-aware answers, eligibility checks, recommendations, catalogue search, small talk, quick options."""
import re, datetime as dt
from app.db import db
CATS = {"electronic": "Electronics", "headphone": "Electronics", "speaker": "Electronics", "watch": "Electronics", "fashion": "Fashion", "shoe": "Fashion", "jeans": "Fashion",
        "shirt": "Fashion", "grocery": "Grocery", "mobile": "Mobiles", "phone": "Mobiles", "laptop": "Laptops", "home": "Home", "book": "Books", "appliance": "Appliances",
        "fridge": "Appliances", "washing": "Appliances", "microwave": "Appliances"}
R = lambda p: re.compile(p, re.I)
GREET, THANKS = R(r"^\s*(hi|hello|hey|namaste|good (morning|afternoon|evening))\b"), R(r"\b(thanks|thank you|thx)\b|^\s*(bye|goodbye)\s*$")
HUMAN, PERS = R(r"\b(human|agent|representative|complain|escalate|speak to)\b"), R(r"\b(my|mine|this order|last order|latest order)\b")
LIST, LATEST = R(r"\b(my orders|order history|past orders|what did i (order|buy)|purchases|previous orders)\b"), R(r"\b(last|latest|recent) order\b|\btrack my\b|\bwhere is my\b|\bstatus of my\b|\bmy order\b")
CANCEL, RETURN, ETA = R(r"\bcancel"), R(r"\b(return|refund|replace|exchange)"), R(r"\b(when|arrive|eta|delivery date|reach)\b")
SPENT, PENDING = R(r"\b(spent|spending|total (amount|paid))\b"), R(r"\b(pending|unpaid)\b|\bpayment status\b")
RECO, PROFILE, ID = R(r"\b(recommend|suggest|for me|based on my)\b"), R(r"\bmy (account|profile|email|name|details|phone)\b"), R(r"\b(ORD[0-9A-Z]{5,}|TRK\d{6,})\b")
SHOP = R(r"\b(best|cheap|cheapest|top|recommend|suggest|show|under|below|above|budget|options|find|need|looking|want|buy|list|less than|more than)\b")

def category(m):
    for k, v in CATS.items():
        if k in m.lower(): return v

def fmt(o):
    items = ", ".join(f"{p['title']} x{p['quantity']}" for p in o["products"])
    return (f"Order {o['order_id']} | Tracking {o['tracking_id']} via {o['courier_partner']} | Shipping: {o['shipping_status']} | Payment: {o['payment_status']} "
            f"({o['payment_method']}) | Delivery date: {o['delivery_date']} | Total Rs {o['total']:,.0f} | Items: {items}")

def cancel_advice(o):
    st, oid = o["shipping_status"], o["order_id"]
    if st == "processing":
        return f"Order {oid} is still processing, so you can cancel it free of charge from My Orders. " + ("No money has been charged (Cash on Delivery)." if o["payment_status"] == "pending" else "Your refund goes to the original payment method in 5-7 business days.")
    if st == "delivered": return f"Order {oid} is already delivered, so it can't be cancelled. If it is within 10 days of delivery you can request a return instead."
    return f"Order {oid} has already shipped ({st}), so it can no longer be cancelled. You can refuse delivery or request a return once it arrives."

def return_advice(o):
    st, oid = o["shipping_status"], o["order_id"]
    if st != "delivered": return f"Order {oid} hasn't been delivered yet (status: {st}, expected {o['delivery_date']}). Returns open after delivery and are allowed for 10 days."
    d = (dt.date.today() - dt.date.fromisoformat(o["delivery_date"])).days; left = 10 - d
    if left >= 0: return f"Order {oid} was delivered {d} days ago, so it is eligible for return for {left} more day(s). Items must be unused with original packaging (grocery and innerwear are not returnable). Refund arrives 5-7 business days after inspection."
    return f"Order {oid} was delivered {d} days ago, so the 10-day return window ended {-left} day(s) ago. Warranty claims may still be possible for eligible products."

def eta_advice(o):
    st = o["shipping_status"]
    if st == "delivered": return f"Order {o['order_id']} was delivered on {o['delivery_date']}."
    return f"Order {o['order_id']} is {st} and expected by {o['delivery_date']} via {o['courier_partner']} (tracking {o['tracking_id']})."

def plist(ps): return "\n".join(f"- {p['title']} ({p['product_id']}) - Rs {p['price']:,.0f}, {p['rating']} stars" for p in ps)

async def catalog(m):
    cat = category(m); hi = re.search(r"\b(under|below|less than|within|upto|up to)\s*(?:rs\.?|₹)?\s*(\d[\d,]*)", m, re.I)
    lo = re.search(r"\b(above|over|more than)\s*(?:rs\.?|₹)?\s*(\d[\d,]*)", m, re.I)
    if not (cat or hi or lo) or not SHOP.search(m): return None
    f = {"stock": {"$gt": 0}}
    if cat: f["category"] = cat
    if hi or lo:
        f["price"] = {}
        if hi: f["price"]["$lte"] = float(hi.group(2).replace(",", ""))
        if lo: f["price"]["$gte"] = float(lo.group(2).replace(",", ""))
    key = ("price", 1) if re.search(r"cheap|budget|lowest", m, re.I) else ("rating", -1)
    ps = await db.products.find(f, {"_id": 0}).sort(*key).to_list(4)
    return ("Here are some options" + (f" in {cat}" if cat else "") + ":\n" + plist(ps)) if ps else "I couldn't find products matching that budget or category."

async def recommend(orders):
    ids = [p["product_id"] for o in orders for p in o["products"] if "product_id" in p]
    bought = await db.products.find({"product_id": {"$in": ids}}, {"category": 1, "_id": 0}).to_list(50)
    cats = sorted({b["category"] for b in bought})
    f = {"stock": {"$gt": 0}, "product_id": {"$nin": ids}}
    if cats: f["category"] = {"$in": cats}
    ps = await db.products.find(f, {"_id": 0}).sort("rating", -1).to_list(4)
    return (f"Based on your past purchases ({', '.join(cats)}), you might like:\n" if cats else "Here are some top-rated picks:\n") + plist(ps)

def small_talk(m, name):
    hi = f" {name}" if name else ""
    if GREET.search(m): return f"Hi{hi}! I'm the ShopEase assistant. I can help with orders, returns, refunds, delivery, payments, warranty and product questions."
    if THANKS.search(m): return f"You're welcome{hi}! Anything else I can help with?"
    if HUMAN.search(m): return "I'm sorry for the trouble. You can reach our support team at support@shopease.example or 1800-000-0000 (Mon-Sat, 9am-8pm IST). Share your order ID and they'll pick it up quickly."

def options(user, extra=None):
    base = ["Track my latest order", "My orders", "Can I return my last order?", "Recommend products for me"] if user else ["Return policy", "Delivery charges", "Payment methods", "Warranty policy", "Contact support"]
    return (extra or []) + [o for o in base if o not in (extra or [])][:5 - len(extra or [])]

async def personal(m, user):
    intent = ID.search(m) or LIST.search(m) or LATEST.search(m) or SPENT.search(m) or PROFILE.search(m) or (RECO.search(m) and not category(m)) \
        or (PERS.search(m) and (CANCEL.search(m) or RETURN.search(m) or ETA.search(m) or PENDING.search(m)))
    if not intent: return None
    if not user:
        if RECO.search(m) and not ID.search(m) and not category(m):
            ps = await db.products.find({"stock": {"$gt": 0}}, {"_id": 0}).sort("rating", -1).to_list(4)
            return {"direct": "Here are some top-rated picks (log in for recommendations based on your orders):\n" + plist(ps), "sources": ["catalogue"], "options": options(None)}
        return "LOGIN"
    orders = await db.orders.find({"user_id": user["user_id"]}, {"_id": 0}).sort("created_at", -1).to_list(50)
    ids = [x.upper() for x in ID.findall(m)]
    sel = [o for o in orders if o["order_id"] in ids or o["tracking_id"] in ids] if ids else []
    if ids and not sel: return {"direct": "I couldn't find that order or tracking ID on your account. Please double-check it.", "sources": [], "options": options(user)}
    if not orders: return {"direct": "You don't have any orders yet. Browse our catalogue and place your first order!", "sources": [], "options": options(user)}
    cur = [o for o in orders if o["shipping_status"] != "delivered"]; done = [o for o in orders if o["shipping_status"] == "delivered"]
    if SPENT.search(m): text = f"You've placed {len(orders)} orders totalling Rs {sum(o['total'] for o in orders):,.0f}."
    elif PROFILE.search(m): text = f"Name: {user['name']} | Email: {user['email']} | Phone: {user.get('phone') or 'not added'} | Orders: {len(orders)} (edit details in Profile)."
    elif RECO.search(m) and not ids: text = await recommend(orders)
    elif LIST.search(m): text = f"You have {len(cur)} current and {len(done)} delivered orders:\n" + "\n".join("- " + fmt(o) for o in orders[:6])
    elif PENDING.search(m) and not ids:
        pend = [o for o in orders if o["payment_status"] == "pending"]
        text = ("Orders with payment pending:\n" + "\n".join("- " + fmt(o) for o in pend)) if pend else "You have no orders with pending payment."
    elif CANCEL.search(m): o = (sel or cur or orders)[0]; text = cancel_advice(o)
    elif RETURN.search(m): o = (sel or done or orders)[0]; text = return_advice(o)
    else:
        o = (sel or orders)[0]; text = fmt(o) + "\n" + eta_advice(o)
    o = (sel or orders)[0]
    return {"direct": text, "sources": ["orders"], "options": options(user, [f"Can I cancel {o['order_id']}?", f"Can I return {o['order_id']}?"])}
