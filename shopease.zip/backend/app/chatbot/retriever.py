"""Tiny dependency-free TF-IDF retriever over data/policies/*.json (one chunk per policy section)."""
import json, math, re, pathlib
from collections import Counter
POL = pathlib.Path(__file__).resolve().parents[2] / "data" / "policies"
STOP = set("the a an is are was to of for and or in on my me i you your it do does can how what when where will be with at by from this that about please".split())
SYN = {"money": "refund", "back": "return", "send": "return", "exchange": "return", "arrive": "delivery", "shipping": "delivery", "deliver": "delivery",
       "cancel": "cancellation", "guarantee": "warranty", "pay": "payment", "upi": "payment", "cod": "payment", "cost": "charges", "fee": "charges"}

def tokens(text):
    out = []
    for w in re.findall(r"[a-z0-9]+", text.lower()):
        if w in STOP or len(w) < 2: continue
        w = w[:-1] if w.endswith("s") and len(w) > 3 else w
        out.append(w)
        if w in SYN: out.append(SYN[w])
    return out

class Retriever:
    def __init__(self):
        self.docs = []
        for f in sorted(POL.glob("*.json")):
            d = json.loads(f.read_text())
            for s in d["sections"]:
                self.docs.append({"slug": d["slug"], "title": d["title"], "heading": s["heading"], "text": s["content"]})
        self.toks = [Counter(tokens(f"{d['title']} {d['title']} {d['heading']} {d['text']}")) for d in self.docs]
        df = Counter(t for c in self.toks for t in c)
        self.idf = {t: math.log(1 + len(self.docs) / n) for t, n in df.items()}

    def search(self, query, k=3):
        q = Counter(tokens(query)); scored = []
        for d, c in zip(self.docs, self.toks):
            num = sum(q[t] * c[t] * self.idf.get(t, 0) ** 2 for t in q if t in c)
            den = math.sqrt(sum((v * self.idf[t]) ** 2 for t, v in c.items())) * math.sqrt(sum((v * self.idf.get(t, 0)) ** 2 for t, v in q.items())) or 1
            scored.append((num / den, d))
        return [(s, d) for s, d in sorted(scored, key=lambda x: -x[0])[:k] if s > 0]
