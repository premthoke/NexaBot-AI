"""ShopEase support bot: intent -> tools (orders, products, policy RAG) -> answer (Claude if ANTHROPIC_API_KEY set, else extractive)."""
import os, re
import httpx
from app.db import db
from app.chatbot.retriever import Retriever, tokens
from app.chatbot import skills

MODEL = os.getenv("ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
class _Lazy:  # build the index on first use so freshly seeded policy files are picked up
    _r = None
    def search(self, q, k=3):
        if self._r is None: self._r = Retriever()
        return self._r.search(q, k)
R = _Lazy()
ORDER_ID = re.compile(r"\bORD[0-9A-Z]{5,}\b", re.I); TRACK_ID = re.compile(r"\bTRK\d{6,}\b", re.I)
ORDER_WORDS = re.compile(r"\b(my orders?|track my|where is my|order status|status of my|has my)\b", re.I)
SYSTEM = ("You are ShopEase's customer support assistant. Answer ONLY from the CONTEXT provided (policies, the customer's own order data, product data). "
          "Be concise, friendly and specific. Address the customer by first name when a CUSTOMER PROFILE is given, and personalise using CUSTOMER DATA. Never invent policies, prices, dates or order details. If the context doesn't answer the question, say so and "
          "direct the customer to support@shopease.example or 1800-000-0000. Never reveal data about other customers.")
HISTORY, SIGNOFF = {}, "If you need more help, contact support@shopease.example or call 1800-000-0000."

def fmt_order(o):
    items = ", ".join(f"{p['title']} x{p['quantity']}" for p in o["products"])
    return (f"Order {o['order_id']} | Tracking {o['tracking_id']} via {o['courier_partner']} | Shipping: {o['shipping_status']} | "
            f"Payment: {o['payment_status']} | Delivery date: {o['delivery_date']} | Total Rs {o['total']} | Items: {items}")

async def find_orders(message, user):
    ids = [m.upper() for m in ORDER_ID.findall(message)]; trks = [m.upper() for m in TRACK_ID.findall(message)]
    if not (ids or trks or ORDER_WORDS.search(message)): return None
    if not user: return "LOGIN_REQUIRED"
    f = {"user_id": user["user_id"]}
    if ids: f["order_id"] = {"$in": ids}
    if trks: f["tracking_id"] = {"$in": trks}
    found = await db.orders.find(f, {"_id": 0}).sort("created_at", -1).to_list(3)
    return found or "NOT_FOUND"

async def find_product(message):
    q = set(tokens(message)); best, score = None, 0
    async for p in db.products.find({}, {"_id": 0, "reviews": 0, "images": 0}):
        s = len(q & set(tokens(f"{p['title']} {p['brand']}")))
        if s > score: best, score = p, s
    return best if score >= 2 else None

def fmt_product(p):
    return (f"{p['title']} | Rs {p['price']} (MRP Rs {p['mrp']}, {p['discount']}% off) | Rating {p['rating']} | "
            f"{'In stock (' + str(p['stock']) + ')' if p['stock'] else 'Out of stock'} | Warranty: {p['warranty']} | Delivery: {p['shipping_time']} | Seller: {p['seller']}")

async def call_gemini(system, msgs):
    body = {"systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]} for m in msgs],
            "generationConfig": {"maxOutputTokens": 1024, "temperature": 0.3}}
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent",
                         headers={"x-goog-api-key": os.environ["GEMINI_API_KEY"]}, json=body)
    r.raise_for_status()
    return r.json()["candidates"][0]["content"]["parts"][0]["text"].strip()

async def answer(message, session_id, user):
    name = user["name"].split()[0] if user else None
    st = skills.small_talk(message, name)
    if st: return {"reply": st, "sources": [], "options": skills.options(user)}
    ctx, sources, direct, opts = [], [], None, skills.options(user)
    if user: ctx.append(f"CUSTOMER PROFILE: name {user['name']}, email {user['email']}, logged in")
    p = await skills.personal(message, user)
    if p == "LOGIN": return {"reply": "Please log in first so I can look up your orders and account securely.", "sources": [], "options": opts}
    if p:
        direct, sources, opts = p["direct"], list(p["sources"]), p["options"]; ctx.append("CUSTOMER DATA:\n" + direct)
    else:
        cat = await skills.catalog(message)
        if cat: direct = cat; ctx.append("CATALOGUE RESULTS:\n" + cat); sources.append("catalogue")
        else:
            prod = await find_product(message)
            if prod: direct = fmt_product(prod); ctx.append("PRODUCT: " + direct); sources.append(prod["product_id"])
    hits = R.search(message, 3)
    if hits and (not direct or hits[0][0] > (0.6 if p else 0.4)):
        ctx += [f"POLICY [{d['title']} - {d['heading']}]: {d['text']}" for _, d in hits]
        top = hits[0][0]; keep = [d for sc, d in hits if sc >= 0.5 * top and d["slug"] == hits[0][1]["slug"]]
        if not direct: direct = f"{keep[0]['title']}:\n" + "\n".join(f"- {d['heading']}: {d['text']}" for d in keep)
        elif p or direct: direct += f"\n\nRelated ({keep[0]['title']}): " + " ".join(d["text"] for d in keep[:2])
        sources += sorted({d["slug"] for d in keep})
    if not direct: return {"reply": "I'm sorry, I couldn't find that in our help information. " + SIGNOFF, "sources": [], "options": opts}
    hist = HISTORY.setdefault(session_id, [])
    reply = direct
    try:
        msgs = hist[-6:] + [{"role": "user", "content": "CONTEXT:\n" + "\n".join(ctx) + f"\n\nCUSTOMER QUESTION: {message}"}]
        if os.getenv("GEMINI_API_KEY"): reply = await call_gemini(SYSTEM, msgs)
        elif os.getenv("ANTHROPIC_API_KEY"):
            from anthropic import AsyncAnthropic
            r = await AsyncAnthropic().messages.create(model=MODEL, max_tokens=400, system=SYSTEM, messages=msgs); reply = r.content[0].text
    except Exception as e: print("LLM error, using extractive answer:", repr(e)[:200])
    hist += [{"role": "user", "content": message}, {"role": "assistant", "content": reply}]
    return {"reply": reply, "sources": sources, "options": opts}
